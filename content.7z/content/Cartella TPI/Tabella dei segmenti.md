
Il numero di segmento è usato come indice.
ogni voce contiene:
	* l'indirizzo base di segmento
	* limite di segmento
Segmentation fault: se verifica se un indirizzo fisico calcolato punta ad un segmento diverso del segmento.