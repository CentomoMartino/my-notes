3 Opzioni: 

[[Segmentazione]]
[[Paginazione]]
[[Mista]]



