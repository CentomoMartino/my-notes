
Questa tecnica ibrida di gestione della memoria prende il meglio delle proposte della Paginazione e Segmentazione.

Paginazione:

		Identificazione dei frame liberi attraverso bit di validità.
		Scelta del frame libero non necessariamente contiguo, senza frammentazione.

Segmentazione:

		Verifica degli accessi e delle operazioni.
		Condivisione di porzioni di memoria.

