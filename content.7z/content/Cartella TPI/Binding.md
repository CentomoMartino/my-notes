Passaggio dall'indirizzo logico a quello fisico.
Rilocazione Statica: Sposare il programma dalla memoria in cui è salvato alla memoria RAM per eseguirlo.
Rilocazione Dinamica: Lo spostamento di un istruzione viene eseguita assieme allo spostamento nella RAM ( Effettuata dalla MMU: Memory Management Unit)