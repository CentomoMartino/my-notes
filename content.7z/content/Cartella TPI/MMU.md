
MMU sta per Memory Management Unit.
Prende l'istuzione dall'HDD nella pagina logica e gli assegna un indirizzo logico, prendendo la pagina logica e l'offset di ogni processo. (es. 0 , 10)
Per l'indirizzo fisico, rileva l'indirizzo della pagina fisica e l'offset (es. 400 , 10)