Swap out: Un processo viene fatto uscire dalla memoria per lasciare spazio ad un altro.

Swap In: Un processo viene portato da una memoria virtuale esterna, all'interno della memoria RAM
