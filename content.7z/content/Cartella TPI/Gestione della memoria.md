[[Binding]]
[[Mappatura]]
[[Multiprogrammazione]]
[[Paginazione]]