
Consente agli stati superiori di accedere ai supporti per inoltrare i dati.
I livelli superiori sono ignari di che protocollo si utilizza al livello data.

Accetta i pacchetti di livello 3 e li incapsula in frame di livello 2.

Controlla i dati in modo che vengano collocato e ricevuti dati sui supporti.

Scambia frame attraverso il supporto di rete tra punti terminali.

		End point riferito alla trasmissione tra dispositivi terminali di una                comunicazione

Supporti: mezzi di trasmissioni
[[Connessione Ethernet]]

[[Topologia]]