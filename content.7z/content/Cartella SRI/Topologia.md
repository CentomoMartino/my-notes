Topologia Fisica: Effettiva disposizione dei dispositivi.![[Pasted image 20241114083400.png]]


Topologia logica: Suddivisione tramite indirizzo IP.![[Pasted image 20241114083446.png]]


<big><big>Connessioni Wan</big></big>

Point to point: ![[Pasted image 20241114084223.png]]


Hub and Spoke: Connessione WAN con un HUB centrale che si collega come Point to Point su ogni dispositivo.![[Pasted image 20241114084253.png]]


Mesh: Sistema in cui ogni dispositivo è direttamente collegato ad ognuno dei dispositivi  presenti sulla rete![[Pasted image 20241114084315.png]]


<big><big>Connessioni LAN </big></big>

Nelle LAN multiaccesso, i dispositivi terminali sono connessi tramite topologie a stella o stella estesa. I dispositivi terminali sono collegati da un dispositivo di rete di livello 2 (spesso uno switch Ethernet), queste topologie sono facili da installare e scalabili (cioè è possibile ampliare la rete a piacimento).

